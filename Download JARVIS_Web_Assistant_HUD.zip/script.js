const micBtn = document.getElementById('mic');
const output = document.getElementById('output');
const clock = document.getElementById('clock');
const batteryDiv = document.getElementById('battery');
const locationDiv = document.getElementById('location');

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition = new SpeechRecognition();

recognition.onstart = () => {
    output.innerHTML = "Listening...";
};

recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript.toLowerCase();
    output.innerHTML = "You said: " + transcript;
    reply(transcript);
};

micBtn.addEventListener('click', () => {
    recognition.start();
});

function reply(message) {
    let response = "";
    if (message.includes("hello")) {
        response = "Hello sir.";
    } else if (message.includes("who are you")) {
        response = "I am JARVIS, your assistant.";
    } else if (message.includes("what's the time")) {
        const now = new Date();
        response = "The time is " + now.toLocaleTimeString();
    } else {
        response = "I'm sorry sir, I didn't catch that.";
    }
    output.innerHTML += "<br>JARVIS: " + response;
    speak(response);
}

function speak(message) {
    const speech = new SpeechSynthesisUtterance(message);
    speech.lang = "en-GB";
    speech.pitch = 1;
    speech.rate = 1;
    window.speechSynthesis.speak(speech);
}

// Show clock
setInterval(() => {
    const now = new Date();
    clock.innerHTML = "Current Time: " + now.toLocaleTimeString();
}, 1000);

// Get battery
if ('getBattery' in navigator) {
    navigator.getBattery().then(battery => {
        function updateBattery() {
            batteryDiv.innerHTML = "Battery: " + Math.round(battery.level * 100) + "%";
        }
        updateBattery();
        battery.addEventListener('levelchange', updateBattery);
    });
} else {
    batteryDiv.innerHTML = "Battery info not supported";
}

// Get location
if ('geolocation' in navigator) {
    navigator.geolocation.getCurrentPosition(pos => {
        const { latitude, longitude } = pos.coords;
        locationDiv.innerHTML = "Location: " + latitude.toFixed(2) + ", " + longitude.toFixed(2);
        speak("Location updated.");
    }, () => {
        locationDiv.innerHTML = "Unable to get location.";
    });
} else {
    locationDiv.innerHTML = "Location not supported";
}
